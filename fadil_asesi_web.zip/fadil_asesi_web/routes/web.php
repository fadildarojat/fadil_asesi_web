<?php

use Illuminate\Support\Facades\Route;
use  App\Http\Controllers\BarangController;
use App\Http\Controllers\PelangganController;
use App\Http\Controllers\PenjualanController;

// route homepage ke barang index
Route::get('/', [BarangController::class, 'index'])->name('barang');

// resource route buat barang
Route::resource('barang', BarangController::class);

// resource route pelanggan
Route::resource('pelanggan', PelangganController::class);

// resou
Route::resource('penjualan', PenjualanController::class);
