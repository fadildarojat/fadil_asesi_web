@extends('layouts.master')
@extends('layouts.navbar')

@section('title', 'Daftar Pelanggan')

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3>Daftar Pelanggan</h3>
        <a href="{{ route('pelanggan.create') }}" class="btn btn-primary">
            Tambah Pelanggan
        </a>
    </div>
    
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No Pelanggan</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($pelanggans as $key => $pelanggan)
                    <tr>
                        <td>{{ $pelanggans->firstItem() + $key }}</td>
                        <td>{{ $pelanggan->no_pelanggan }}</td>
                        <td>{{ $pelanggan->nama_pelanggan }}</td>
                        <td>{{ $pelanggan->alamat ?? '-' }}</td>
                        <td>
                            <a href="{{ route('pelanggan.edit', $pelanggan) }}" class="btn btn-sm btn-warning">Edit</a>
                            <form action="{{ route('pelanggan.destroy', $pelanggan) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center">Belum ada data pelanggan</td>
                    </tr>
                @endforelse
            </tbody>
        </table>

        <div class="mt-3">{{ $pelanggans->links() }}</div>
    </div>
</div>
@endsection