<?php

namespace Database\Seeders;

use App\Models\Barang;
use Illuminate\Database\Seeder;

class BarangSeeder extends Seeder
{
    // seeder buat isi data barang
    public function run(): void
    {
        // data contoh barang
        $dataBarang = [
            [
                'kode_barang' => '59932',
                'nama_barang' => 'Laptop Dell',
                'harga_barang' => 120000
            ],
            [
                'kode_barang' => '92882',
                'nama_barang' => 'Mouse Skull',
                'harga_barang' => 350000
            ],
        ];
        
        // insert ke database
        foreach ($dataBarang as $barang) {
            Barang::create($barang);
        }
    }
}