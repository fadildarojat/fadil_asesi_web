


<?php $__env->startSection('title', 'Daftar Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3>Daftar Barang</h3>
        <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-primary">
            Tambah Barang
        </a>
    </div>
    
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Harga Barang</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($barangs->firstItem() + $key); ?></td>
                        <td><?php echo e($barang->kode_barang); ?></td>
                        <td><?php echo e($barang->nama_barang); ?></td>
                        <td>Rp <?php echo e(number_format($barang->harga_barang, 0, ',', '.')); ?></td>
                        <td>
                            <a href="<?php echo e(route('barang.edit', $barang)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('barang.destroy', $barang)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">Belum ada data barang</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3"><?php echo e($barangs->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fadil\OneDrive\ドキュメント\web\fadil_asesi_web\resources\views/barang/index.blade.php ENDPATH**/ ?>