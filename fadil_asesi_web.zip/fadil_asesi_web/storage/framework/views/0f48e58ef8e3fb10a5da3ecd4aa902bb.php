<nav class="navbar navbar-expand-lg bg-body-tertiary mb-5">
 <div class="container-fluid">
   <ul class="navbar-nav me-auto mb-2 mb-lg-0">
     <a class="navbar-brand" href="#"></a>
     
     <li class="nav-item">
       <a class="nav-link" href="/barang">Barang</a>&nbsp;
     </li>
     
     <li class="nav-item">
       <a class="nav-link" href="/pelanggan">Pelanggan</a>&nbsp;
     </li>
     
     <li class="nav-item">
       <a class="nav-link" href="/penjualan">Penjualan</a>&nbsp;
     </li>
   </ul>
 </div>
</nav><?php /**PATH C:\Users\Fadil\OneDrive\ドキュメント\web\fadil_asesi_web\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>