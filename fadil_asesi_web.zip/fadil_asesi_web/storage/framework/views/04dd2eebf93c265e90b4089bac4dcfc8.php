


<?php $__env->startSection('title', 'Daftar Pelanggan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3>Daftar Pelanggan</h3>
        <a href="<?php echo e(route('pelanggan.create')); ?>" class="btn btn-primary">
            Tambah Pelanggan
        </a>
    </div>
    
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No Pelanggan</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($pelanggans->firstItem() + $key); ?></td>
                        <td><?php echo e($pelanggan->no_pelanggan); ?></td>
                        <td><?php echo e($pelanggan->nama_pelanggan); ?></td>
                        <td><?php echo e($pelanggan->alamat ?? '-'); ?></td>
                        <td>
                            <a href="<?php echo e(route('pelanggan.edit', $pelanggan)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('pelanggan.destroy', $pelanggan)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">Belum ada data pelanggan</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3"><?php echo e($pelanggans->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Fadil\OneDrive\ドキュメント\web\fadil_asesi_web\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>