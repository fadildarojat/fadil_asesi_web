<?php

namespace App\Http\Controllers;

use App\Models\Pelanggan;
use Illuminate\Http\Request;

class PelangganController extends Controller
{
    // list pelanggan
    public function index()
    {
        // ambil data terbaru dulu, terus di paginate biar ga berat
        $pelanggans = Pelanggan::latest()->paginate(10);
        return view('pelanggan.index', compact('pelanggans'));
    }

    // form tambah pelanggan
    public function create()
    {
        return view('pelanggan.create');
    }

    // simpan data pelanggan baru
    public function store(Request $request)
    {
        $request->validate([
            'no_pelanggan' => 'required|unique:pelanggans',
            'nama_pelanggan' => 'required',
            'alamat' => 'nullable'
        ]);

        Pelanggan::create($request->all());

        return redirect()->route('pelanggan.index')
                         ->with('success', 'Pelanggan berhasil ditambahkan');
    }

    // nampilin form edit
    public function edit(Pelanggan $pelanggan)
    {
        return view('pelanggan.edit', compact('pelanggan'));
    }

    // update data pelanggan
    public function update(Request $request, Pelanggan $pelanggan)
    {
        $request->validate([
            'nama_pelanggan' => 'required',
            'alamat' => 'nullable'
        ]);

        $pelanggan->update($request->all());

        return redirect()->route('pelanggan.index')
                         ->with('success', 'Data pelanggan berhasil diupdate');
    }

    // hapus pelanggan
    public function destroy(Pelanggan $pelanggan)
    {
        $pelanggan->delete();
        
        return redirect()->route('pelanggan.index')
                         ->with('success', 'Pelanggan berhasil dihapus');
    }
}