<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\Pelanggan;
use App\Models\Penjualan;

// controller dashboard
class DashboardController extends Controller
{
    // menampilkan dashboard utama
    public function index()
    {
        // hitung total masing-masing
        $totalBarang = Barang::count();
        $totalPelanggan = Pelanggan::count();
        $totalPenjualan = Penjualan::count();
        
        // kirim ke view
        return view('dashboard', compact(
            'totalBarang', 
            'totalPelanggan', 
            'totalPenjualan'
        ));
    }
}