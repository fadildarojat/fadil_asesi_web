<?php

namespace App\Http\Controllers;

use App\Models\Penjualan;
use Illuminate\Http\Request;

// controller penjualan
class PenjualanController extends Controller
{
    // list semua penjualan
    public function index()
    {
        // ambil penjualan terbaru
        $dataPenjualan = Penjualan::latest()->paginate(10);
        return view('penjualan.index', compact('dataPenjualan'));
    }

    // form tambah penjualan
    public function create()
    {
        // ambil semua data pelanggan buat dropdown
        $pelanggans = \App\Models\Pelanggan::all();
        return view('penjualan.create', compact('pelanggans'));
    }

    // simpan penjualan baru
    public function store(Request $request)
    {
        // validasi dulu
        $validasi = $request->validate([
            'faktur_id' => 'required|max:6',
            'no_pelanggan' => 'required|max:6',
            'tanggal_penjualan' => 'date'
        ]);

        // simpan ke database
        Penjualan::create($validasi);

        return redirect()->route('penjualan.index')
                        ->with('succes', 'penjualan berhasil ditambahkan');
    }

    // show detail penjualan
    public function show(string $id)
    {
        $penjualan = Penjualan::findOrFail($id);
        return view('penjualan.show', compact('penjualan'));
    }

    // form edit penjualan
    public function edit(string $id)
    {
        $penjualan = Penjualan::findOrFail($id);
        return view('penjualan.edit', compact('penjualan'));
    }

    // update data penjualan
    public function update(Request $request, string $id)
    {
        $validasi = $request->validate([
            'faktur_id' => 'required|max:6',
            'no_pelanggan' => 'required|max:6',
            'tanggal_penjualan' => 'date'
        ]);

        $penjualan = Penjualan::findOrFail($id);
        $penjualan->update($validasi);

        return redirect()->route('penjualan.index')
                        ->with('success', 'Penjualan berhasil diperbarui');
    }

    // hapus data penjualan
    public function destroy(string $id)
    {
        $penjualan = Penjualan::findOrFail($id);
        $penjualan->delete();
        
        return redirect()->route('penjualan.index')
                        ->with('success', 'Penjualan berhasil dihapus');
    }
}
