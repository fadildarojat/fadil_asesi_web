<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use Illuminate\Http\Request;

// Controller untuk handle CRUD barang
class BarangController extends Controller
{
    // nampilin list barang
    public function index()
    {
        // ambil data terbaru dulu, terus di paginate biar ga berat
        $barangs = Barang::latest()->paginate(10);
        return view('barang.index', compact('barangs'));
    }

    // form tambah barang
    public function create()
    {
        return view('barang.create');
    }

    // simpan data barang baru ke db
    public function store(Request $request)
    {
        $validasi = $request->validate([
            'kode_barang' => 'required|min:0',
            'nama_barang' => 'required|max:50',
            'harga_barang' => 'required|numeric|min:0'
        ]);

        Barang::create($validasi);

        return redirect()->route('barang.index')
                         ->with('success', 'Barang berhasil ditambahkan');
    }

    // nampilin form edit
    public function edit(Barang $barang)
    {
        return view('barang.edit', compact('barang'));
    }

    // update data barang
    public function update(Request $request, Barang $barang)
    {
        $validasi = $request->validate([
            'kode_barang' => 'required|min:0',
            'nama_barang' => 'required|max:50',
            'harga_barang' => 'required|numeric|min:0'
        ]);

        $barang->update($validasi);

        return redirect()->route('barang.index')
                         ->with('success', 'Data barang berhasil diupdate');
    }

    // hapus barang
    public function destroy(Barang $barang)
    {
        $barang->delete();
        
        return redirect()->route('barang.index')
                         ->with('success', 'Barang berhasil dihapus');
    }
}