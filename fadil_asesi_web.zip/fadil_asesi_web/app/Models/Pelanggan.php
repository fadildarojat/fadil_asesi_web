<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pelanggan extends Model
{
    protected $table = 'pelanggans';

    protected $fillable = [
        'no_pelanggan',
        'nama_pelanggan',
        'alamat'
    ];

    // relasi ke penjualan (one to many)
    // 1 pelanggan bisa punya banyak penjualan
    public function penjualans()
    {
        return $this->hasMany(\App\Models\Penjualan::class, 'no_pelanggan', 'no_pelanggan');
    }
}
