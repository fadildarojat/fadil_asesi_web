<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Penjualan extends Model
{
    protected $table = 'penjualans';

    protected $fillable = [
        'faktur_id',
        'no_pelanggan',
        'tanggal_penjualan'
    ];

    // relasi ke pelanggan
    public function pelanggan()
    {
        return $this->belongsTo(Pelanggan::class, 'no_pelanggan', 'no_pelanggan');
    }

    // relasi many to many ke barang
    public function barang()
    {
        return $this->belongsToMany(Barang::class)->withPivot('aty', 'harga');
    }
}
